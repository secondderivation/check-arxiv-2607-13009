# Scoped check of arXiv:2607.13009v1

**Unreleased candidate, version 0.1.0-rc2. Owner approval pending.**

Paper: *Model-Independent Indication for a Localized Anomaly in the Late-Time Expansion History*, S. Gupta Choudhury, P. Mukherjee, E. Di Valentino, A. A. Sen. [Frozen paper version](https://arxiv.org/abs/2607.13009v1).

**Result:** the exact pressure/distance/NEC identities reproduce under their stated premises. Our specified numerical reconstruction is consistent with the paper's no-NEC-violation-evidence statement. This numerical agreement is conditional on our implementation. The paper's headline significance has not been established by this package; no major error finding is asserted.

## Scope

- **A1:** exact GR / flat-FLRW identities, including limiting cases. [Output](reference/algebra.json).
- **N1:** no negative upper 97.5% pointwise NEC percentile on the tested grid for either of our two closures, with and without the negative-pressure prior, across two seeds. This is a new post-hoc, conditional claim related to the paper's NEC statement, not author-chain reproduction.

Not covered as reproduced results: the headline 3.5-sigma maximum and its location, the paper's numerical calibration, all robustness variants, the printed mock table, or global significance. See [methods and limitations](METHODS.md), [protocol](PROTOCOL.md) and [validation](VALIDATION.md). The original broader review conclusions are not silently replaced by these narrowed claims.

## Saved conditional results

H below is H(z)/(1+z) at z=.47, in km/s/Mpc. These values are implementation diagnostics. They are not a tension estimate or a certified reproduction of the paper's quoted numbers. The last column is the minimum, across the grid, of the upper pointwise NEC percentile; a positive value is absence of the specified violation signal, not proof of the NEC.

| Closure / prior / seed | ESS | Max weight | H mean | H SD | Min upper 97.5% NEC |
|---|---:|---:|---:|---:|---:|
| I2_RA_20261009 | 43250 | 0.000031 | 60.718259 | 0.476714 | 0.315300 |
| I2_RA_731009 | 43080 | 0.000031 | 60.712073 | 0.478577 | 0.315300 |
| I2_REIRA_20261009 | 7662 | 0.000175 | 60.783766 | 0.454961 | 0.315300 |
| I2_REIRA_731009 | 7537 | 0.000177 | 60.768247 | 0.456820 | 0.315300 |
| I4_RA_20261009 | 43231 | 0.000031 | 60.647847 | 0.481043 | 0.411726 |
| I4_RA_731009 | 43062 | 0.000031 | 60.640974 | 0.482943 | 0.411331 |
| I4_REIRA_20261009 | 7538 | 0.000178 | 60.719394 | 0.460589 | 0.409402 |
| I4_REIRA_731009 | 7460 | 0.000179 | 60.700414 | 0.461847 | 0.408715 |

Each row is saved in `reference/<row-name>.json`; its full NEC percentile curves are in `reference/<row-name>_nec.json`. No redshift averaging was used.

## Run everything

Use Python 3.14. Dependencies are pinned. Network access is needed for installation and the first data download. The full local runtime is recorded in [ENVIRONMENT.md](ENVIRONMENT.md); machine speed varies.

```sh
python3.14 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -B reproduce.py --all
```

A successful run verifies the immutable payload, four data hashes, exact identities, all eight fits, numerical diagnostics, saved-reference comparisons and independent-seed stability. Results go to `_runs/`; saved outputs are never overwritten. A nonzero exit means the package did not pass. [Validation details](VALIDATION.md).

## Data and attribution

DESI DR2 BAO and DES-Dovekie supernova inputs are fetched from commit-pinned upstream URLs and SHA-256 checked. [Dataset records and acknowledgments](datasets.json) identify the sources. [Acknowledgments](ACKNOWLEDGMENTS.md). Data are not bundled or relicensed. The .npz packed array is treated as precision, as explained in METHODS.md.

## Review disclosure

AI-assisted checks used Anthropic for the initial review and OpenAI for a blind recheck, an informed critic and this informed package preparation. These are two providers. The critic had access to earlier results. This package preparation is not a fresh-context P2 review. Agreement between models is not independent scientific evidence. [Effort disclosure](effort.json) distinguishes unknown measurements from zero and does not invent missing model identifiers or token counts.

## Release and licence

This candidate does not authorize publication. Owner routing, the author-information process, independent P2 verification and approval tied to the exact artifact and destination remain separate gates. No code here publishes or sends messages. Remote CI is supplied for future use; it has not been run for this unpushed candidate.

Code: [BSD-3-Clause](LICENSE). Original prose: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). See [COPYRIGHT.md](COPYRIGHT.md). Citation metadata: [CITATION.cff](CITATION.cff). No release DOI has been assigned.
